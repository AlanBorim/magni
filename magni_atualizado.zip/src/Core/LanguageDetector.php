<?php

namespace App\Core;

class LanguageDetector
{
    private static $supportedLanguages = ['en' => 'en', 'pt' => 'pt'];
    private static $defaultLanguage = 'pt';

    /**
     * Detecta o idioma com base na URL e redireciona se necessário.
     */
    public static function detectLanguage(): array
    {
        $uri = trim($_SERVER['REQUEST_URI'], '/'); // Remove barras adicionais
        $segments = explode('/', $uri);

        $languageCode = $segments[0] ?? null;

        if (isset(self::$supportedLanguages[$languageCode])) {
            return [
                'language' => self::$supportedLanguages[$languageCode],
                'basePath' => '/' . $languageCode,
            ];
        }

        // Redireciona para o idioma padrão
        self::redirectToDefaultLanguage();
        return [
            'language' => self::$defaultLanguage,
            'basePath' => '/' . self::$defaultLanguage,
        ];
    }

    /**
     * Redireciona para o idioma padrão.
     */
    private static function redirectToDefaultLanguage(): void
    {
        $currentUrl = rtrim($_SERVER['REQUEST_URI'], '/');
        header("Location: /" . self::$defaultLanguage . $currentUrl);
        exit;
    }
}
